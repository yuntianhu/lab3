## Toy Order Management System Documentation
This document provides an overview of the Toy Order Management System, including instructions on installation, usage, and running the application.

### Table of Contents
Introduction
Installation
Usage
Running the Application
Additional Information

### 1. Introduction
The Toy Order Management System is a web-based application built to manage toy orders. It consists of three main components:

Frontend Server: Provides a user interface for customers to place orders.
Catalog Server: Manages the catalog of available toys and their quantities.
Order Server Replicas: Manage the order database and process incoming orders.
### 2. Installation
Prerequisites
Before installing the Toy Order Management System, ensure you have the following prerequisites installed:

### Docker
Python (if not included in your system)
Installation Steps
Clone the repository from GitHub:
```
git clone <repository_url>
cd toy-order-management-system
```
Install the required Python libraries:
```
pip install -r requirements.txt
```
3. Usage
Starting the Servers
To start the servers, use Docker Compose:
```
docker-compose up
```
This command will start the Frontend Server, Catalog Server, and Order Server Replicas.

Accessing the Application
Once the servers are running, you can access the application using the following URLs:

Frontend Server: http://localhost:5000
Catalog Server: http://localhost:5001
Order Server Replica 1: http://localhost:5002
Order Server Replica 2: http://localhost:5003
Order Server Replica 3: http://localhost:5004

### 4. Running the Application
Development Mode
For development purposes, you can run each component separately:

Frontend Server:
```
python frontend_server.py
```
Catalog Server:
```
python catalog_server.py
```
Order Server Replica:
```
python order_server_replica.py
```
