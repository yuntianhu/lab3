I tested the code separatedly and togther.

While I was testing the code separately, I used curl to test their end points.

After files tested sepreately. I wrote a mock testing client to test all the files together to see if they are working correctly.

Use Mock client to test the if whole program work correctly. and the result is as screenshot below
![327626185-25d9291b-8e12-46e6-a5ab-9cb2a5cd3df2](https://github.com/umass-cs677-current/spring24-lab3-yuntian/assets/48864579/c109f82a-cda0-4481-a17c-cbd60be09001)

Use curl to test query function work correctly in front end server work correclty, and the result is as screenshot below
![327626181-ac8a19e0-1609-481c-b1c5-13b872075df5](https://github.com/umass-cs677-current/spring24-lab3-yuntian/assets/48864579/5203a9d2-bf5b-4358-9155-4aa4c419d90a)

Use curl to test purchase function work correctly in front end server, and the result is as screenshot below
![327626180-d37dd6a5-6d17-47a7-908f-c356b295c587](https://github.com/umass-cs677-current/spring24-lab3-yuntian/assets/48864579/bdfae730-f539-4d5c-bdbf-1978013f1093)

Use curl to test query function work correctly in catalog server, and the result is as screenshot below
![327626179-60af00a3-45a2-48dc-be1b-d4d71b55737f](https://github.com/umass-cs677-current/spring24-lab3-yuntian/assets/48864579/3fcd4bda-0777-4ee7-898b-3d215ed03918)

Use curl to test query set leader function work correctly in order server, and the result is as screenshot below
![327626176-d621047b-ac6b-4e08-a4d8-1e44e7dc5aa4](https://github.com/umass-cs677-current/spring24-lab3-yuntian/assets/48864579/312c2037-caf2-4525-9e03-a3c639a5ec0c)

and this is the result for order had been recorded in the csv file
![327626174-47bf9811-98e7-47a0-a350-df6f38a7de28](https://github.com/umass-cs677-current/spring24-lab3-yuntian/assets/48864579/0f6496a0-62f5-4425-8e6f-08307fe61c1c)
