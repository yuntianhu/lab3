from flask import Flask, request, jsonify
import requests
import threading
from collections import OrderedDict

app = Flask(__name__)
cache = OrderedDict()
MAX_CACHE_SIZE = 10
CATALOG_URL = "localhost:5001"
ORDER_URLS = ["localhost:5002", "localhost:5003", "localhost:5004"]
LEADER_URL = None
LEADER_LOCK = threading.Lock()
IsLeaderSet= False

def update_cache(key, value):
    if len(cache) >= MAX_CACHE_SIZE:
        cache.popitem(last=False)
    cache[key] = value

def remove_cache(key):
    if key in cache:
        del cache[key]

def set_leader():
    global LEADER_URL
    global IsLeaderSet
    for url in ORDER_URLS:
        if not IsLeaderSet:
            response = requests.put(f"{url}/set_leader/true")
            if response.status_code == 200:
                LEADER_URL = url
                IsLeaderSet= True
            else:
                LEADER_URL = ""
                IsLeaderSet= False
        if IsLeaderSet:
            response = requests.put(f"{url}/set_leader/false")

def get_leader():
    global LEADER_URL
    for url in ORDER_URLS:
        try:
            response = requests.get(f"{url}/is_leader")
            if response.status_code == 200:
                LEADER_URL = url
                break
        except Exception as e:
            print(f"Error connecting to {url}: {e}")

def forward_request_to_leader(data):
    global LEADER_URL
    if not LEADER_URL:
        get_leader()
    try:
        response = requests.post(f"{LEADER_URL}/process_order", json=data)
        return response.json()
    except Exception as e:
        print(f"Error forwarding request to leader: {e}")

@app.route('/products/<product_name>', methods=['GET'])
def get_product(product_name):
    if product_name in cache:
        return jsonify(cache[product_name])

    response = requests.get(f"{CATALOG_URL}/products/{product_name}")
    if response.status_code == 200:
        product = response.json()
        update_cache(product_name, product)
        return jsonify(product)
    else:
        return jsonify({"error": "Product not found"}), 404

@app.route('/orders', methods=['POST'])
def place_order():
    data = request.json
    order_response = forward_request_to_leader(data)
    if order_response:
        return jsonify(order_response)
    else:
        return jsonify({"error": "Failed to place order"}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
