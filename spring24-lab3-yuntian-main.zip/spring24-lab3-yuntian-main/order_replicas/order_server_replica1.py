from flask import Flask, jsonify, request
import threading
import requests
import csv
import uuid
import json

app = Flask(__name__)
Leader = {"leader":True}
LEADER = Leader["leader"]
ORDER_FILE = 'db3.csv'
db= {
    "fox": {"name": "Fox", "quantity": 100, "price": 100},
    "dolphin": {"name": "Dolphin", "quantity": 100, "price": 100},
    "python": {"name": "Python", "quantity": 100, "price": 100},
    "cat": {"name": "Cat", "quantity": 100, "price": 50},
    "dog": {"name": "Dog", "quantity": 100, "price": 50},
    "bull": {"name": "Bull", "quantity": 100, "price": 100},
    "sheep": {"name": "Sheep", "quantity": 100, "price": 50},
    "cow": {"name": "Cow", "quantity": 100, "price": 100},
    "rabbit": {"name": "Rabbit", "quantity": 100, "price": 50},
    "mouse": {"name": "Mouse", "quantity": 100, "price": 50},
    "moose": {"name": "Moose", "quantity": 100, "price": 100},
}
order_db={}

def write_data(order_data, new_data):
    # Update the local replica database (in this case, write to the CSV file)
    with open(ORDER_FILE, 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(list(order_data.values())+list(new_data.values()))

def process_order(order_data):
    global order_db
    global LEADER
    # Process the order
    # Update order database
    order_number = uuid.uuid4().hex
    new_data = {"order_number":order_number}
    order_db[order_number] = order_data
    order_db["order_number"]= order_number
    write_data(order_data, new_data)

    return {"order_number": order_number}

def sync_replica(order_number, order_data):
    # Synchronize the replica with the leader
    replicas = ['localhost:5003/update_replica', 'localhost:5004/update_replica']
    for replica_url in replicas:
        try:
            response = requests.post(replica_url, json=order_data)
            if response.status_code == 200:
                print(f"Successfully updated {replica_url}")
            else:
                print(f"Failed to update {replica_url}. Status code: {response.status_code}")
        except Exception as e:
            print(f"Error updating {replica_url}: {e}")

@app.route('/process_order', methods=['POST'])
def process_order_route():
    global LEADER
    if LEADER:
        order_data = request.json
        product_name = order_data.get('product_name')

        # Check if the product exists in the catalog and its quantity is greater than 0
        if product_name in db and db[product_name]['quantity'] > 0:
            response = process_order(order_data)
            threading.Thread(target=sync_replica, args=(response['order_number'], order_data)).start()
            return jsonify(response)
        else:
            return jsonify({"error": "Product not available or out of stock"}), 400
    else:
        return jsonify({"error": "Not the leader"}), 403

@app.route('/update_replica', methods=['POST'])
def update_replica_route():
    order_data = requests.json
    # Update the local replica database (in this case, write to the CSV file)
    with open(ORDER_FILE, 'a', newline='') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow([order_data['order_number']] + list(order_data.values()))
    return jsonify({"message": "Replica updated successfully"}), 200

@app.route('/set_leader/<LeaderOrNot>', methods=['PUT'])
def set_leader(LeaderOrNot):
    global Leader
    global LEADER
    if LeaderOrNot.lower() == 'true':
        Leader["leader"] = True
        LEADER = Leader["leader"]
    elif LeaderOrNot.lower() == 'false':
        Leader["leader"] = False
        LEADER = Leader["leader"]
    else:
        return jsonify({"error": "Invalid value for leader"}), 400
    return jsonify({"message": "Leader changed successfully"}), 200

@app.route('/is_leader', methods=['GET'])
def is_leader():
    global LEADER
    return jsonify({"leader": LEADER })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5002)
