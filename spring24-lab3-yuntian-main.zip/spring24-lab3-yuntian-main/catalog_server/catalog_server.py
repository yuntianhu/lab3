from flask import Flask, jsonify
import threading
import time

app = Flask(__name__)
catalog = {}
RESTOCK_INTERVAL = 10

def restock_catalog():
    global catalog
    while True:
        for product in catalog:
            if catalog[product]['quantity'] == 0:
                catalog[product]['quantity'] = 100
        time.sleep(RESTOCK_INTERVAL)

@app.route('/products/<product_name>', methods=['GET'])
def get_product(product_name):
    if product_name in catalog:
        return jsonify(catalog[product_name])
    else:
        return jsonify({"error": "Product not found"}), 404

if __name__ == '__main__':
    threading.Thread(target=restock_catalog, daemon=True).start()
    app.run(host='0.0.0.0', port=5001)
