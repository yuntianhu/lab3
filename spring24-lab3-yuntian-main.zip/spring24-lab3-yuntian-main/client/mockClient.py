import requests

# Base URL of the Flask server
BASE_URL = "http://localhost:5000"

# List of product names for which information is requested
product_names = ["tiger", "cow", "fox", "elephent", "bull", "cat", "dog", "cat", "python", "fox"]

# Perform 10 product information requests
for product_name in product_names:
    response = requests.get(f"{BASE_URL}/products/{product_name}")
    if response.status_code == 200:
        print(f"Info for {product_name}: {response.json()}")
    else:
        print(f"Failed to get info for {product_name}: {response.status_code}")

# Data for 5 purchase requests
purchase_data = [
    {"product_name": "cow", "quantity": 1},
    {"product_name": "fox", "quantity": 1},
    {"product_name": "sox", "quantity": 1},
    {"product_name": "python", "quantity": 1},
    {"product_name": "cat", "quantity": 1}
]

# Perform 5 purchase requests
for order in purchase_data:
    response = requests.post(f"{BASE_URL}/orders", json=order)
    if response.status_code == 200:
        print(f"Order placed successfully: {response.json()}")
    else:
        print(f"Failed to place order: {response.status_code}, {response.json()}")
